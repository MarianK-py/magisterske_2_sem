module PaliStvorce where

-- Marian Kravec

parPocetCif :: Integer -> Bool
parPocetCif n | n < 10 = False
              | otherwise = not $ parPocetCif (n `div` 10)

palindrom :: String -> Bool
palindrom [] = True
palindrom (s:[]) = True
palindrom s = ((head s) == (last s)) && (palindrom (init $ tail s))

nte :: Int -> Integer
nte i = test 32 1
        where
          test n k | parPocetCif (n^2) = if palindrom $ show (n^2)
                                         then if k == i
                                              then n^2
                                              else test (n+1) (k+1)
                                         else test (n+1) k
                   | otherwise = test (ceiling ((fromInteger n)*3.1622776601683795)) k
