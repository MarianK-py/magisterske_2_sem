dolezite_casti -> obsahuje iba samotny kod a report
kompletny_projekt -> obsahuje to co dolezite_casti aj vygenerovane grafy, napísaný tex, vygenerovane tabulky v texu